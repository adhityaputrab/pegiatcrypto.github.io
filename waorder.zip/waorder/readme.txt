=== WA ORDER ===
Contributors: fiqhid24
Requires at least: 5.0
Tested up to: 5.3
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Theme wordpress yang akan memudahkan anda dalam berjualan di toko online whatsapp dengan segudang fitur

== Description ==
Theme wordpress yang akan memudahkan anda dalam berjualan di toko online whatsapp dengan segudang fitur

== Frequently Asked Questions ==

== Changelog ==

= 2.3.0 =
* Add one click Update

= 2.2.1 =
* Fixing Bug Ongkir

== Upgrade Notice ==

== Resources ==
