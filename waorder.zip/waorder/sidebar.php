<aside class="sidebar" role="complementary">

	<?php get_template_part( 'searchform' ); ?>

	<div class="widget">
		<?php if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'widget-post-1' ) ) ?>
	</div>

</aside>
