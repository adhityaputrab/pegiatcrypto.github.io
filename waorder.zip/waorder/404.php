<?php get_header(); ?>

	<section class="index">

		<div class="wrapper clear">

			<div class="boxcontainer clear">

				<?php get_template_part('template/404'); ?>

			</div>

		</div>
	</section>

<?php get_footer(); ?>
